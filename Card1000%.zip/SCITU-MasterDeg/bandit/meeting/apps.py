from django.apps import AppConfig


class MeetingConfig(AppConfig):
    name = 'meeting'
