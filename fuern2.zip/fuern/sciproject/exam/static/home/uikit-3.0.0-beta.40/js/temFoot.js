Function myFunction0() {
    var x = document.getElementById("hide00");
    if (x.style.display === "none") {
        x.style.display = "block";
        document.getElementById('hide0').value  = "-";
    } else {
        x.style.display = "none";
        document.getElementById('hide0').value  = "+";
    }
}

function myFunction1() {
    var x = document.getElementById("hide11");
    if (x.style.display === "none") {
        x.style.display = "block";
        document.getElementById('hide1').value  = "-";
    } else {
        x.style.display = "none";
        document.getElementById('hide1').value  = "+";
    }
}

function myFunction2() {
    var x = document.getElementById("hide22");
    if (x.style.display === "none") {
        x.style.display = "block";
        document.getElementById('hide2').value  = "-";
    } else {
        x.style.display = "none";
        document.getElementById('hide2').value  = "+";
    }
}

function myFunction3() {
    var x = document.getElementById("hide33");
    if (x.style.display === "none") {
        x.style.display = "block";
        document.getElementById('hide3').value  = "-";
    } else {
        x.style.display = "none";
        document.getElementById('hide3').value  = "+";
    }
}